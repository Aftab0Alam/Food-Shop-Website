const express = require('express');
const path=require('path');
const app = express();
const hbs=require('hbs');
 require("./db/conn"); // Connect to MongoDB database.
 const Register=require('./models/register');
const port =process.env.PORT || 3000;
 
const static_path =path.join(__dirname,  "../public" );
const templates_path =path.join(__dirname,  "../templates/views" );
const partials_path =path.join(__dirname,  "../templates/partials" );

app.use(express.json());

app.use(express.urlencoded({ extended: false }));
// console.log(path.join(__dirname,"../public"));
app.use(express.static(static_path));
app.set("view engine","hbs");
app.set("views",templates_path);

hbs.registerPartials(partials_path);

app.get('/', (req, res) => {
  res.render('index');
});

app.get("/login", (req, res) => {
  res.render('login');
})


app.get("/register", (req, res) => {
   res.render('register'); 
   });
   app.post("/register",async (req, res) => {
try{
  const password=req.body.password;
  const cpassword=req.body.confirmpassword;
  if(password===cpassword){
      const user=new Register({
         firstname:req.body.firstname,
         lastname:req.body.lastname,
         email:req.body.email,
         age:req.body.age,
         gender:req.body.gender,
         phone:req.body.phone,
         password:password,
         confirmpassword:cpassword
         
      })
      const  result=await user.save();
       res.status(201).render("./main");
    }
  else{
    res.send("Passwords do not match");
  }
}catch(err){
  res.status(400).send(err);
}



   })

// login authentication
app.post('/login',async(req,res)=>{
try{
  
  const email=req.body.email;
  const Password=req.body.Password;
 


  const useremail= await Register.findOne({email:email});
    if(useremail.password===Password){
      res.status(200).render("./main");
    }else{
      res.status(400).send("password incorrect");
    }

    
}catch(error){
  res.status(400).send("invalid email");
}
})
   app.get("/login", (req, res) => {
    res.render('login'); 
    });

app.listen(port,() => {
    console.log(`Server is running on port ${port}`);
});
 
