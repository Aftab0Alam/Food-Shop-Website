
const mongoose = require('mongoose');

const MONGODB_URI = 'mongodb://localhost:27017/aftabdb';

mongoose.connect(MONGODB_URI, {
    

    
}).then(() => {
    console.log('Connected to MongoDB');

}).catch((err) => {
    console.log("not connected to mongodb");
});